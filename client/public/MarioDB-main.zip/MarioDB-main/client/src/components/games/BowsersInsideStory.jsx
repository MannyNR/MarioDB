const BowsersInsideStory = (props) => {
  const { characters } = props;
  return (
    <div className="bowsers-inside-story">
      <h1>{games.name}</h1>
      <h2>{games.characters}</h2>

    </div>
  )
}
export default BowsersInsideStory