const MarioTennisAces = (props) => {
  const { characters } = props;
  return (
    <div className="mario-tennis-aces">
      <h1>{games.name}</h1>
      <h2>{games.characters}</h2>

    </div>
  )
}
export default MarioTennisAces